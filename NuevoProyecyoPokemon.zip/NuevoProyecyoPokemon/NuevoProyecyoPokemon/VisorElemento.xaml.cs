﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Control de usuario está documentada en https://go.microsoft.com/fwlink/?LinkId=234236

namespace NuevoProyecyoPokemon
{
    public sealed partial class VisorElemento : UserControl
    {
        private bool verEnergia = false;
        private bool verSalud = false;
        
        public VisorElemento()
        {
            this.InitializeComponent();
            
        }
        public double Vida
        {
            get { return this.pbHealth.Value; }
            set { this.pbHealth.Value = value; }
        }
        public void verFondo(bool fondo)
        {
            if (!fondo) {
                this.grid.Background = null;
            }
            
        }
        
        public bool VerEnergia
        {
            get { return verEnergia; }
            set
            {
                this.verEnergia = value;
                if (!verEnergia) this.grid.RowDefinitions[1].Height = new GridLength(0);
                else this.grid.RowDefinitions[1].Height = new GridLength(89.6, GridUnitType.Star);
            }
        }
        
        public bool VerSalud
        {
            get { return verSalud; }
            set
            {
                this.verSalud = value;
                if (!verSalud) this.grid.RowDefinitions[0].Height = new GridLength(0);
                else this.grid.RowDefinitions[0].Height = new GridLength(90.4, GridUnitType.Star);
            }
        }
        public void animacion_estatica(bool begin)
        {
            Storyboard sb = (Storyboard)this.Resources["MoverAlas"];
            if (begin)
            {
                sb.Begin();
            }
            else sb.Stop();
            

        }
        public void VolverEstadoInicial(bool begin)
        {
            Storyboard sb = (Storyboard)this.Resources["VolverAlEstadoInicial"];
            if (begin)
            {
                sb.Begin();
            }
            else sb.Stop();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.animaciones.Visibility = Visibility.Collapsed;
            this.Atacar.Visibility = Visibility.Visible;
            this.protegerse.Visibility = Visibility.Visible;
            this.descansar.Visibility = Visibility.Visible;
            this.Cargar_energia.Visibility = Visibility.Visible;
            this.volver.Visibility = Visibility.Visible;
            this.ulti.Visibility = Visibility.Visible;
        }

        private void volver_click(object sender, RoutedEventArgs e)
        {
            this.animaciones.Visibility = Visibility.Visible;
            this.Atacar.Visibility = Visibility.Collapsed;
            this.protegerse.Visibility = Visibility.Collapsed;
            this.descansar.Visibility = Visibility.Collapsed;
            this.Cargar_energia.Visibility = Visibility.Collapsed;
            this.volver.Visibility = Visibility.Collapsed;
            this.ulti.Visibility = Visibility.Collapsed;

        }

        private void atacar_click(object sender, RoutedEventArgs e)
        {

            this.animacion_estatica(false);
            Storyboard sb = (Storyboard)this.Resources["Recuperar_Vitalidad"];
            sb.Begin();
            sb.AutoReverse = true;
            sb.Completed += finAnimacion;
            this.Atacar.IsEnabled = false;
            this.protegerse.IsEnabled = false;
            this.descansar.IsEnabled = false;
            this.Cargar_energia.IsEnabled = false;
            this.ulti.IsEnabled = false;
            this.Atacar.Visibility = Visibility.Collapsed;
            this.protegerse.Visibility = Visibility.Collapsed;
            this.descansar.Visibility = Visibility.Collapsed;
            this.Cargar_energia.Visibility = Visibility.Collapsed;
            this.volver.Visibility = Visibility.Collapsed;
            this.ulti.Visibility = Visibility.Collapsed;

        }
        private void finAnimacion(object sender, object e)
        {
            this.animacion_estatica(true);
            this.Atacar.IsEnabled = true;
            this.protegerse.IsEnabled = true;
            this.descansar.IsEnabled = true;
            this.Cargar_energia.IsEnabled = true;
            this.ulti.IsEnabled = true;
            this.Atacar.Visibility = Visibility.Visible;
            this.protegerse.Visibility = Visibility.Visible;
            this.descansar.Visibility = Visibility.Visible;
            this.Cargar_energia.Visibility = Visibility.Visible;
            this.volver.Visibility = Visibility.Visible;
            this.ulti.Visibility = Visibility.Visible;

        }
        private void finAnimacionDano(object sender, object e)
        {
            this.ojoDerecho.Visibility = Visibility.Visible;
            this.ojoIzquierdo.Visibility = Visibility.Visible;
            this.pupilaDerecha.Visibility = Visibility.Visible;
            this.pupilaIzquierda.Visibility = Visibility.Visible;
            this.Ojo_derecho_cerrado_dano.Visibility = Visibility.Collapsed;
            this.Ojo_izquierdo_cerrado_dano.Visibility = Visibility.Collapsed;
            this.animacion_estatica(true);
            this.Atacar.IsEnabled = true;
            this.protegerse.IsEnabled = true;
            this.descansar.IsEnabled = true;
            this.Cargar_energia.IsEnabled = true;
            this.ulti.IsEnabled = true;
        }

        private void protegerse_click(object sender, RoutedEventArgs e)
        {
            this.animacion_estatica(false);
            Storyboard sb = (Storyboard)this.Resources["Protegerse"];
            sb.Begin();
            sb.Completed += finAnimacion;
            this.Atacar.IsEnabled = false;
            this.protegerse.IsEnabled = false;
            this.descansar.IsEnabled = false;
            this.Cargar_energia.IsEnabled = false;
            this.ulti.IsEnabled = false;

        }

        private void descansar_click(object sender, RoutedEventArgs e)
        {
            this.animacion_estatica(false);
            Storyboard sb = (Storyboard)this.Resources["Descansar"];
            sb.Begin();
            sb.Completed += finAnimacion;
            this.Atacar.IsEnabled = false;
            this.protegerse.IsEnabled = false;
            this.descansar.IsEnabled = false;
            this.Cargar_energia.IsEnabled = false;
            this.ulti.IsEnabled = false;
            this.Atacar.Visibility = Visibility.Collapsed;
            this.protegerse.Visibility = Visibility.Collapsed;
            this.descansar.Visibility = Visibility.Collapsed;
            this.Cargar_energia.Visibility = Visibility.Collapsed;
            this.volver.Visibility = Visibility.Collapsed;
            this.ulti.Visibility = Visibility.Collapsed;

        }

        private void cargar_click(object sender, RoutedEventArgs e)
        {
            this.animacion_estatica(false);
            Storyboard sb = (Storyboard)this.Resources["Energetico"];
            sb.Begin();
            sb.RepeatBehavior = new RepeatBehavior(1);
            sb.Completed += finAnimacion;
            this.Atacar.IsEnabled = false;
            this.protegerse.IsEnabled = false;
            this.descansar.IsEnabled = false;
            this.Cargar_energia.IsEnabled = false;
            this.ulti.IsEnabled = false;
        }

        private void cuerpo_click(object sender, PointerRoutedEventArgs e)
        {
            this.animacion_estatica(false);
            Storyboard sb = (Storyboard)this.Resources["Recibir_dano"];
            sb.Begin();
            sb.Completed += finAnimacionDano;
            this.Atacar.IsEnabled = false;
            this.protegerse.IsEnabled = false;
            this.descansar.IsEnabled = false;
            this.Cargar_energia.IsEnabled = false;
            this.ulti.IsEnabled = false;
        }

        private void ulti_click(object sender, RoutedEventArgs e)
        {
            this.animacion_estatica(false);
            Storyboard sb = (Storyboard)this.Resources["AtaqueRojo"];
            sb.Begin();
            sb.Completed += finAnimacion;
            this.Atacar.IsEnabled = false;
            this.protegerse.IsEnabled = false;
            this.descansar.IsEnabled = false;
            this.Cargar_energia.IsEnabled = false;
            this.ulti.IsEnabled = false;
            this.Atacar.Visibility = Visibility.Collapsed;
            this.protegerse.Visibility = Visibility.Collapsed;
            this.descansar.Visibility = Visibility.Collapsed;
            this.Cargar_energia.Visibility = Visibility.Collapsed;
            this.volver.Visibility = Visibility.Collapsed;
            this.ulti.Visibility = Visibility.Collapsed;
        }
    }
}
